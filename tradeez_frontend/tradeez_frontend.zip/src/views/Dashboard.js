import React from "react";
import SideBar from "../components/SideBar/SideBar";

const Dashboard = () => {
  return <div><SideBar></SideBar></div>;
};

export default Dashboard;
