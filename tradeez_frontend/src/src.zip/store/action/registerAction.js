import axios from "axios";
import {
  REGISTER_INPROGRESS,
  REGISTER_SUCCESS,
  REGISTER_FAILED,
} from "./actionTypes.js";
