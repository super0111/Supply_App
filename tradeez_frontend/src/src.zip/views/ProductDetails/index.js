import Top from "./Top"
import BoughtTogether from "./BoughtTogether"

const ProductView = () => {
  return (
    <div className="details1">
      <Top />
      <BoughtTogether />
    </div>
  )
}
export default ProductView