const roles = {
  Seller: "seller",
  Buyer: "buyer",
};

export default roles;
